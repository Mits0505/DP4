package composite;

public class CompositeTest {

	public static void main(String[] args) {
		Component hd = new Leaf(4000,"Harddrive");
		Component mouse = new Leaf(1000,"Mouse");
		Component monitor = new Leaf(10000,"Monitor");
		Component ram = new Leaf(2000,"RAM");
		Component cpu = new Leaf(12000,"CPU");
		
		Composite ph = new Composite("Peripherals");
		Composite mb = new Composite("Mother Board");
		Composite cabinet = new Composite("Cabinet");
		Composite computer = new Composite("Computer");
		
		ph.addComponent(mouse);
		ph.addComponent(monitor);
		
		mb.addComponent(ram);
		mb.addComponent(cpu);
		
		cabinet.addComponent(hd);
		cabinet.addComponent(mb);
		
		computer.addComponent(cabinet);
		computer.addComponent(ph);
		
		computer.showPrice();
	}

}
