package adapter.marker;

public class PilotPen {

	public void mark(String str){
		System.out.println(str);
	}
}
