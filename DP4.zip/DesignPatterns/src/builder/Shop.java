package builder;

import builder.phone.Phone;

public class Shop {

	public static void main(String[] args) {
		PhoneBuilder phoneBuilder = new PhoneBuilder();
		Phone phone = phoneBuilder.setOs("Android").setRam(2).setBattery(3000).getPhone();
		
        System.out.println(phone);
	}

}
